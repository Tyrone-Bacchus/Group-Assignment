import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class ColorPanel extends JPanel
{
	private ImageIcon image;	//the actual image to be displayed
	private int tester = -1;
	private boolean border;
	private UnitStorage panelUnits;

	public ColorPanel(int i)
	{
		tester = i;
		setPreferredSize(new Dimension(48, 48));	//each tile is size-determined!
		Random gen = new Random();
		border = false;
		panelUnits = null;

		if(i == 1)	//for the player's cities
		{
			image = Resources.rCity;
		}
		else if(i == 2)	//for the AI's cities
		{
			image = Resources.bCity;
		}
		else if(i == 3)	//the forests
		{
			int chooseF = gen.nextInt(4);

			if(chooseF == 0)
			{
				image = Resources.forest1;
			}
			else if(chooseF == 1)
			{
				image = Resources.forest2;
			}
			else if(chooseF == 2)
			{
				image = Resources.forest3;
			}
			else
			{
				image = Resources.forest4;
			}
		}
		else if(i == 4)	//mountains
		{
			image = Resources.mountain;
		}
		else if(i == 5)	//the plains / DEFAULT area
		{
			image = Resources.plains;
		}
		//next two are the borders
		else if(i == 6)
		{
			image = Resources.lBorder;
		}
		else if(i == 7)
		{
			image = Resources.rBorder;
		}
		else if(i == 8)	//the river; you can't stand on, but can pass over!!
		{
			image = Resources.river;
		}
		else	//the lakes
		{
			image = Resources.lake;
		}
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		image.paintIcon(this, g, 0, 0);

		if(border == true)
		{
			g.setColor(Color.yellow);
			g.drawRect(0, 0, getWidth()-1, getHeight()-1);
		}
	}

	public void setClicked()
	{
		if(border == true)
		{
			border = false;
		}
		else
		{
			border = true;
		}

		repaint();
	}

	public String getTile()
	{
		if(tester == 1 || tester == 2)
		{
			return "This is a town";
		}
		else if(tester == 3)
		{
			return "This is a forest";
		}
		else if(tester == 4 || tester == 9)
		{
			return "This is an uncrossable terrain";
		}
		else
		{
			return "These are some plains";
		}
	}

	public UnitStorage getUnitStorage()
	{
		return panelUnits;
	}
}